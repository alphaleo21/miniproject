<?php
session_start();
include_once('includes/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $userMobile = $_POST['userMobile'];
    $userEmail = $_POST['userEmail'];
    $eventId = $_POST['eventId'];

    // Insert user information into the 'users' table
    $insertUserQuery = mysqli_query($con, "INSERT INTO users (fname, lname, mobile, email) VALUES ('$fname', '$lname', '$userMobile', '$userEmail')");
    if ($insertUserQuery) {
        // Get the user ID
        $userId = mysqli_insert_id($con);

        // Insert entry into 'participants' table with user ID and event ID
        $insertParticipantQuery = mysqli_query($con, "INSERT INTO participants (user_id, event_id) VALUES ('$userId', '$eventId')");
        if ($insertParticipantQuery) {
            echo "Success! Participant registered.";
        } else {
            echo "Error inserting participant.";
        }
    } else {
        echo "Error inserting user.";
    }
} else {
    echo "Invalid request.";
}
?>
