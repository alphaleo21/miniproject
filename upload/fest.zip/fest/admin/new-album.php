<?php
session_start();
include_once('../includes/config.php');

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
} else {
    // Code for User Creation
    if (isset($_POST['album'])) {
        $album = $_POST['album'];

        $query = mysqli_query($con, "INSERT INTO albums (album_name)
                                    VALUES ('$album')");

        if ($query) {
            echo "<script>alert('album created successfully');</script>";
            echo "<script type='text/javascript'> document.location = 'manage-albums.php'; </script>";
        } else {
            echo "<script>alert('Error creating album');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Create Album</h1>
                    <div class="card mb-4">
                        <form method="post">
                            <div class="card-body">
                                <!-- Your form inputs go here -->
                                <div class="mb-3">
                                    <label for="category" class="form-label">Album Name</label>
                                    <input type="text" class="form-control" id="album" name="album" required>
                                </div>
                                
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary" name="create">Create Album</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
            <?php include('../includes/footer.php');?>
        </div>
    </div>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
</body>
</html>
