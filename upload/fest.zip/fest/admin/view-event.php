<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Event </title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
            }

            td {
                padding: 8px; /* Adjust padding as needed */
                min-width: 100px; /* Set the minimum width as per your requirement */
                border: 1px solid #ddd; /* Add borders or adjust styles as needed */
            }
            </style>
    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
<?php 
$eventid=$_GET['uid'];
$qry = "SELECT * FROM events join event_category on event_category.id = events.category_id where events.id=$eventid";
$query=mysqli_query($con, $qry);
while($result=mysqli_fetch_array($query))
{
    ?>
                        <h1 class="mt-4"><?php echo $result['event_name'];?></h1>
                        <div class="card mb-4">
                     
                            <div class="card-body">
                                <table class="table table-bordered">
                                   <tr>
                                    <th>Event Name</th>
                                       <td><?php echo $result['event_name'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Date of event</th>
                                       <td><?php echo date('d F Y', strtotime($row['date_of_event']));?></td>
                                   </tr>
                                   <tr>
                                       <th>Venue</th>
                                       <td><?php echo $result['venue'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Created At</th>
                                       <td colspan="3"><?php echo $result['created_at'];?></td>
                                   </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php }   
                    $qry = "SELECT users.*, participants.event_id
                              FROM users
                              JOIN participants ON users.id = participants.user_id
                              WHERE participants.event_id = $eventid";
                    $query = mysqli_query($con, $qry);
                    ?>
                    <table>
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <!-- Add more user details as needed -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($query)) {
                                echo "<tr>";
                                echo "<td>{$row['id']}</td>";
                                echo "<td>{$row['fname']} {$row['lname']}</td>";
                                echo "<td>{$row['mobile']}</td>";
                                echo "<td>{$row['email']}</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
