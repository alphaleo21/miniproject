<?php
session_start();
include_once('../includes/config.php');

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
} else {
    // Fetch albums from the database
    $albumsQuery = mysqli_query($con, "SELECT * FROM albums");
    $albums = mysqli_fetch_all($albumsQuery, MYSQLI_ASSOC);

    // Code for Image Creation
    if (isset($_POST['create'])) {
        $caption = $_POST['caption'];
        $albumId = $_POST['album_id'];

        // Perform validation and error handling as needed

        // Upload image file
        $targetDir = "uploads/";  // Adjust the directory path based on your setup
        $targetFile = $targetDir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "<script>alert('File is not an image.');</script>";
            $uploadOk = 0;
        }

        // Check if file already exists
        if (file_exists($targetFile)) {
            echo "<script>alert('Sorry, file already exists.');</script>";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["file"]["size"] > 5000000) {
            echo "<script>alert('Sorry, your file is too large.');</script>";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif") {
            echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');</script>";
            $uploadOk = 0;
        }
        $filename = $targetFile;
        $targetFile = "/var/www/html/project2/fest/".$targetFile;
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<script>alert('Sorry, your file was not uploaded.');</script>";
        } else {
            $mv = move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile);
            if ($mv) {
                $query = mysqli_query($con, "INSERT INTO images (caption, album_id, filename)
                                              VALUES ('$caption', '$albumId', '$filename')");

                if ($query) {
                    echo "<script>alert('Image created successfully');</script>";
                    echo "<script type='text/javascript'> document.location = 'manage-images.php'; </script>";
                } else {
                    echo "<script>alert('Error creating image');</script>";
                }
            } else {
                echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Upload Image</h1>
                    <div class="card mb-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="caption" class="form-label">Caption</label>
                                    <input type="text" class="form-control" id="caption" name="caption" required>
                                </div>
                                <div class="mb-3">
                                    <label for="album_id" class="form-label">Album</label>
                                    <select id="album_id" name="album_id" class="form-control" required>
                                        <?php
                                        foreach ($albums as $album) {
                                            echo "<option value='{$album['id']}'>{$album['album_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="file" class="form-label">Select Image</label>
                                    <input type="file" class="form-control" id="file" name="file" accept="image/*" required>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary" name="create">Upload Image</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
            <?php include('../includes/footer.php');?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
</body>
</html>
