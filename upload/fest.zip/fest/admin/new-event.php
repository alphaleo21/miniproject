<?php
session_start();
include_once('../includes/config.php');

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
} else {
    // Code for Event Creation
    if (isset($_POST['create'])) {
        $eventName = $_POST['event_name'];
        $dateOfEvent = $_POST['date_of_event'];
        $categoryId = $_POST['category_id'];
        $venue = $_POST['venue'];
        $status = $_POST['status'];

        // Perform validation and error handling as needed
        $targetDir = "uploads/events/";  // Adjust the directory path based on your setup
        $targetFile = $targetDir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "<script>alert('File is not an image.');</script>";
            $uploadOk = 0;
        }

        // Check if file already exists
        if (file_exists($targetFile)) {
            echo "<script>alert('Sorry, file already exists.');</script>";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["file"]["size"] > 5000000) {
            echo "<script>alert('Sorry, your file is too large.');</script>";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif") {
            echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');</script>";
            $uploadOk = 0;
        }
        $filename = $targetFile;
        $targetFile = "/var/www/html/project2/fest/".$targetFile;
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<script>alert('Sorry, your file was not uploaded.');</script>";
        } else {
            $mv = move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile);
            if ($mv) {
               
                $query = mysqli_query($con, "INSERT INTO events (event_name, date_of_event, category_id, venue, status, image)
                                      VALUES ('$eventName', '$dateOfEvent', '$categoryId', '$venue', '$status', '$filename')");

                if ($query) {
                    echo "<script>alert('Image created successfully');</script>";
                    echo "<script type='text/javascript'> document.location = 'manage-events.php'; </script>";
                } else {
                    echo "<script>alert('Error creating image');</script>";
                }
            } else {
                echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
            }
        }

        

        if ($query) {
            echo "<script>alert('Event created successfully');</script>";
            echo "<script type='text/javascript'> document.location = 'manage-events.php'; </script>";
        } else {
            echo "<script>alert('Error creating event');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');
         $categoriesQuery = mysqli_query($con, "SELECT * FROM event_category");
         $categories = mysqli_fetch_all($categoriesQuery, MYSQLI_ASSOC);
    ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Create Event</h1>
                    <div class="card mb-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="event_name" class="form-label">Event Name</label>
                                    <input type="text" class="form-control" id="event_name" name="event_name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="date_of_event" class="form-label">Date of Event</label>
                                    <input type="date" class="form-control" id="date_of_event" name="date_of_event" required>
                                </div>
                                <div class="mb-3">
                                    <label for="category_id" class="form-label">Category ID</label>
                                    <select id="category_id" name="category_id" class="form-control" required>
                                        <?php
                                        foreach ($categories as $category) {
                                            echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="venue" class="form-label">Venue</label>
                                    <input type="text" class="form-control" id="venue" name="venue" required>
                                </div>
                                <div class="mb-3">
                                    <label for="file" class="form-label">Select Image</label>
                                    <input type="file" class="form-control" id="file" name="file" accept="image/*" required>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select id="status" name="status" class="form-control" required>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary" name="create">Create Event</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
            <?php include('../includes/footer.php');?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
</body>
</html>
